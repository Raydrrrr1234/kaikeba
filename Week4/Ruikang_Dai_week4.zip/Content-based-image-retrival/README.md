# 开课吧小组作业之 Content Based Image Retrival
File name: index.py
           search.py
#### Dependency:

- python3.6+
- pip install numpy
- pip install opencv_contrib_python==3.4
- pip install argparse

#### Generate index of images

``
python index.py -d path/to/images -i index.csv
``

#### Test image search function

``
python search.py -i index.csv -q query_image.jpg -r path/to/images
``
