##
# Data: 2020/2/24 Mon
# Author: Ruikang Dai
# Description: Kaikeba homework week 4 project
##

import random
import numpy as np
import random
import time
import cv2
import argparse
import concurrent.futures



def nonRepeatRandom(count, kp_set):
    sample = tuple(random.sample(range(count), 4))
    while sample in kp_set:
        sample = tuple(random.sample(range(count), 4))
    kp_set.add(tuple(sample))
    return sample


def intTuple(t):
    return tuple([round(i) for i in t])

def ransac(kl, kr, iter=100, error=0.11, thresh_size=0.90):
    best_match = 0
    p_set = set()
    sample_number = len(kl)
    left_points = np.array([[i.pt for i in kl]], dtype=np.float32)
    best_idx = []
    for _ in range(iter):
        cur = nonRepeatRandom(sample_number, p_set)
        lp, rp = np.float32([kl[i].pt for i in cur]), np.float32([kr[i].pt for i in cur])
        M = cv2.getPerspectiveTransform(rp, lp)
        right_points = np.array([[i.pt for i in kr]], dtype=np.float32)
        warpped = cv2.perspectiveTransform(right_points, M)
        error_array = np.sqrt(np.sum(np.square(warpped-left_points), axis=0))
        cur_match = np.sum(error_array < error)
        if cur_match > best_match:
            best_idx = cur
            best_match = cur_match
            #print('Found a better match:', best_match)
        if best_match > sample_number * thresh_size:
            break
    return best_idx

# 删减掉四周的黑框
def trim(frame):
    # crop top
    if not np.sum(frame[0]):
        return trim(frame[1:])
    # crop bottom
    elif not np.sum(frame[-1]):
        return trim(frame[:-2])
    # crop left
    elif not np.sum(frame[:, 0]):
        return trim(frame[:, 1:])
    # crop right
    elif not np.sum(frame[:, -1]):
        return trim(frame[:, :-2])
    return frame


class STITCHING(object):

    def __init__(self, im_l, im_r, alg='sift', ransac_alg='cv2', nfeatures=1500, thread_num=1):
        self.ratio = 0.75
        self.im_l = cv2.imread(im_l)
        self.im_r = cv2.imread(im_r)
        self.gray_l = cv2.cvtColor(self.im_l, cv2.COLOR_BGR2GRAY)
        self.gray_r = cv2.cvtColor(self.im_r, cv2.COLOR_BGR2GRAY)
        if alg == 'sift':
            self.alg = cv2.xfeatures2d.SIFT_create()
        if alg == 'surf':
            self.alg = cv2.xfeatures2d.SURF_create()
        if alg == 'orb':
            self.alg = cv2.ORB_create(nfeatures=nfeatures)
        self.keypoints_l, self.descriptors_l = self.alg.detectAndCompute(self.gray_l, None)
        self.keypoints_r, self.descriptors_r = self.alg.detectAndCompute(self.gray_r, None)

        # 匹配特征点
        matcher = cv2.BFMatcher()

        matches1 = matcher.knnMatch(self.descriptors_l, self.descriptors_r, k=2)
        matches2 = matcher.knnMatch(self.descriptors_r, self.descriptors_l, k=2)

        # 删除距离过远的点
        _, matches1 = self.ratio_test(matches1)
        _, matches2 = self.ratio_test(matches2)

        # 对称匹配
        sym_matches = self.symmetry_test(matches1, matches2)

        kl = [self.keypoints_l[i.queryIdx] for i in sym_matches]
        kr = [self.keypoints_r[i.trainIdx] for i in sym_matches]

        # 计算变换矩阵
        if ransac_alg != 'cv2':
            best_match = ransac(kl, kr)
            kpl = np.float32([intTuple(kl[i].pt) for i in best_match])
            kpr = np.float32([intTuple(kr[i].pt) for i in best_match])
            M = cv2.getPerspectiveTransform(kpr, kpl)
        else:
            ptsr, ptsl = np.float32([i.pt for i in kr]), np.float32([i.pt for i in kl])
            M, mask = cv2.findHomography(ptsr, ptsl, cv2.RANSAC, 5.0)

        # 用M变换右图并且拼接到左图上
        self.dst = cv2.warpPerspective(self.im_r, M, (self.im_l.shape[1] + self.im_r.shape[1], self.im_l.shape[0]))
        self.dst[0:self.im_l.shape[0], 0:self.im_l.shape[1]] = self.im_l


    def get_stitching(self):
        return trim(self.dst)

    def symmetry_test(self, matches1, matches2):
        symmetric_matches = []
        for match1 in matches1:
            if len(match1) < 2:
                continue
            for match2 in matches2:
                if len(match2) < 2:
                    continue
                if match1[0].queryIdx == match2[0].trainIdx and match2[0].queryIdx == match1[0].trainIdx:
                    symmetric_matches.append(cv2.DMatch(match1[0].queryIdx, match1[0].trainIdx, match1[0].distance))
                    break
        return symmetric_matches

    def ratio_test(self, matches):
        removed = 0
        for match in matches:
            if len(match) > 1:
                if match[0].distance / match[1].distance > self.ratio:
                    match.clear()
                    removed += 1
            else:
                match.clear()
                removed += 1
        return removed, matches

ap = argparse.ArgumentParser()
ap.add_argument('-d', '--default', required=False, action='store_true',
                help='Run default tests, cv2 RANSAC by default')
ap.add_argument('-s', '--self', required=False, action='store_false',
                help='Run selfmade RANSAC Algorithm in Python')
ap.add_argument('-l', '--left', required=False,
                help='without --default, put left image here')
ap.add_argument('-r', '--right', required=False,
                help='without --default, put right image here')
args = vars(ap.parse_args())

if args["default"]:
    if args["self"]:
        s1 = STITCHING('lenna50l.jpg', 'lenna50r.jpg', ransac_alg='cv2')
        cv2.imshow('result1', s1.get_stitching())
        cv2.waitKey(50)
        s2 = STITCHING('mt_l.png', 'mt_r.png', ransac_alg='cv2')
        cv2.imshow('result2', s2.get_stitching())
        cv2.waitKey(0)
    else:
        s3 = STITCHING('lenna50l.jpg', 'lenna50r.jpg', ransac_alg='')
        cv2.imshow('result3', s3.get_stitching())
        cv2.waitKey(50)
        s4 = STITCHING('mt_l.png', 'mt_r.png', ransac_alg='')
        cv2.imshow('result4', s4.get_stitching())
        cv2.waitKey(0)

else:
    if args["self"]:
        s5 = STITCHING(args["left"], args["right"], ransac_alg='cv2')
        cv2.imshow('result5', s5.get_stitching())
        cv2.waitKey(0)
    else:
        s6 = STITCHING(args["left"], args["right"], ransac_alg='')
        cv2.imshow('result5', s6.get_stitching())
        cv2.waitKey(0)