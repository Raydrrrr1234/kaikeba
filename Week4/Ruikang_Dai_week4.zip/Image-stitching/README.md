# 开课吧作业之 Image Stitching
File name: image_stitching.py
#### Dependency:

- python3.6+
- pip install numpy
- pip install opencv_contrib_python==3.4.2
- pip install argparse

#### Test Cv2 RANSAC function with default examples

``
python image_stitching.py -d
``

#### Test self-made RANSAC function with default examples

``
python image_stitching.py -d -s
``

#### Test Cv2 RANSAC function with other images

``
python image_stitching.py -l mt_l.png -r mt_r.png
``

#### Test self-made RANSAC function with other images

``
python image_stitching.py -s -l mt_l.png -r mt_r.png
``